export const columnChartSquare = {
    chart: {
        aspectRatio: 1
    }
};
export const columnChartMaxSpace = {
    chart: {
        flex: 1,
        aspectRatio: undefined
    }
};
